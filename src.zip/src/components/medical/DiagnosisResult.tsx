"use client";

import { motion } from "framer-motion";
import {
  Stethoscope,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Heart,
  Activity,
  ChevronDown,
  Phone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import type { DiagnosisResult as DiagnosisResultType } from "@/lib/decision-tree";

interface DiagnosisResultProps {
  diagnosis: DiagnosisResultType;
  aiEnhanced?: boolean;
  onRestart: () => void;
}

function UrgencyBadge({ urgency }: { urgency: string }) {
  if (urgency === "طارئ") {
    return (
      <motion.div
        className="inline-flex items-center gap-2 bg-red-600 text-white px-5 py-2.5 rounded-xl text-lg font-bold"
        animate={{ scale: [1, 1.05, 1], opacity: [1, 0.9, 1] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
      >
        <span className="text-xl">🚨</span>
        حالة طوارئ - تتطلب تدخلاً فورياً
      </motion.div>
    );
  }
  if (urgency === "عاجل") {
    return (
      <div className="inline-flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-xl text-base font-bold">
        <span className="text-lg">⚠️</span>
        حالة عاجلة - تحتاج مراجعة طبية سريعة
      </div>
    );
  }
  return (
    <div className="inline-flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded-xl text-base font-bold">
      <span className="text-lg">✅</span>
      غير عاجل - يمكن مراجعة الطبيب بشكل روتيني
    </div>
  );
}

export default function DiagnosisResult({ diagnosis, aiEnhanced, onRestart }: DiagnosisResultProps) {
  const [showAdvice, setShowAdvice] = useState(true);
  const [showWarnings, setShowWarnings] = useState(true);

  const urgency = diagnosis.urgency || "غير عاجل";
  const isEmergency = urgency === "طارئ";

  const confidenceColor =
    diagnosis.confidence >= 80
      ? "bg-teal-500"
      : diagnosis.confidence >= 65
      ? "bg-gold"
      : "bg-coral";

  const confidenceLabel =
    diagnosis.confidence >= 80
      ? "احتمال مرتفع"
      : diagnosis.confidence >= 65
      ? "احتمال متوسط"
      : "احتمال منخفض";

  return (
    <div className="min-h-screen bg-background">
      {/* Emergency Banner */}
      {isEmergency && (
        <motion.div
          className="bg-red-600 text-white py-3 px-4 text-center"
          animate={{ opacity: [1, 0.7, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="flex items-center justify-center gap-2 text-lg font-bold">
            <Phone className="w-5 h-5" />
            <span>🚨 حالة طوارئ - اتصل بالإسعاف فوراً 🚨</span>
            <Phone className="w-5 h-5" />
          </div>
        </motion.div>
      )}

      {/* Header */}
      <header className={`py-8 px-4 ${isEmergency ? 'bg-gradient-to-l from-red-700 to-red-600' : 'bg-gradient-to-l from-teal-800 to-teal-600'}`}>
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/15 backdrop-blur-sm mb-4"
          >
            <Activity className="w-8 h-8 text-white" />
          </motion.div>
          <h1 className="text-2xl font-bold text-white mb-2">نتيجة التشخيص المبدئي</h1>
          {aiEnhanced && (
            <Badge className="bg-coral/20 text-white border-coral/30">
              ✨ مدعوم بالذكاء الاصطناعي
            </Badge>
          )}
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 -mt-6 pb-8">
        {/* Urgency Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mb-4"
        >
          <UrgencyBadge urgency={urgency} />
        </motion.div>

        {/* Main Diagnosis Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className={`border-2 shadow-xl ${isEmergency ? 'border-red-300 shadow-red-100/50' : 'border-teal-300 shadow-teal-100/50'}`}>
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className={`text-2xl sm:text-3xl font-bold mb-3 leading-relaxed ${isEmergency ? 'text-red-800' : 'text-teal-800'}`}>
                    {diagnosis.name}
                  </CardTitle>
                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge
                      className={`${confidenceColor} text-white text-sm px-3 py-1`}
                    >
                      {confidenceLabel} - {diagnosis.confidence}%
                    </Badge>
                    <Badge variant="outline" className={`text-sm px-3 py-1 ${isEmergency ? 'border-red-300 text-red-700' : 'border-teal-300 text-teal-700'}`}>
                      <Stethoscope className="w-3.5 h-3.5 ml-1" />
                      {diagnosis.specialty}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Confidence Bar */}
              <div className="mb-6">
                <div className={`w-full h-2 rounded-full overflow-hidden ${isEmergency ? 'bg-red-100' : 'bg-teal-100'}`}>
                  <motion.div
                    className={`h-full rounded-full ${confidenceColor}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${diagnosis.confidence}%` }}
                    transition={{ duration: 1.2, ease: "easeOut", delay: 0.5 }}
                  />
                </div>
              </div>

              {/* Description */}
              <p className="text-foreground leading-relaxed text-base">
                {diagnosis.description}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recommended Specialty */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-6"
        >
          <Card className={`border bg-opacity-50 ${isEmergency ? 'border-red-200 bg-red-50/50' : 'border-teal-200 bg-teal-50/50'}`}>
            <CardContent className="p-5">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${isEmergency ? 'bg-red-600' : 'bg-teal-600'}`}>
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className={`text-sm font-medium ${isEmergency ? 'text-red-600' : 'text-teal-600'}`}>التخصص الموصى بزيارته</h3>
                  <p className={`text-lg font-bold ${isEmergency ? 'text-red-800' : 'text-teal-800'}`}>{diagnosis.specialty}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Advice Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-6"
        >
          <Card className="border border-teal-200">
            <button
              onClick={() => setShowAdvice(!showAdvice)}
              className="w-full p-5 flex items-center justify-between hover:bg-teal-50/50 transition-colors rounded-t-xl"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold-light/50 flex items-center justify-center">
                  <Lightbulb className="w-5 h-5 text-gold-dark" />
                </div>
                <h3 className="text-lg font-bold text-teal-800">نصائح وتوصيات أولية</h3>
              </div>
              <motion.div
                animate={{ rotate: showAdvice ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-teal-600" />
              </motion.div>
            </button>

            {showAdvice && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <CardContent className="pt-0 pb-5 px-5">
                  <ul className="space-y-3">
                    {diagnosis.advice.map((item, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: 0.1 * index }}
                        className="flex items-start gap-3"
                      >
                        <ShieldCheck className="w-5 h-5 text-teal-500 flex-shrink-0 mt-0.5" />
                        <span className="text-foreground leading-relaxed">{item}</span>
                      </motion.li>
                    ))}
                  </ul>
                </CardContent>
              </motion.div>
            )}
          </Card>
        </motion.div>

        {/* Warning Signs Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-6"
        >
          <Card className={`border-2 bg-opacity-5 ${isEmergency ? 'border-red-300 bg-red-500/5' : 'border-coral/30 bg-coral/5'}`}>
            <button
              onClick={() => setShowWarnings(!showWarnings)}
              className={`w-full p-5 flex items-center justify-between transition-colors rounded-t-xl ${isEmergency ? 'hover:bg-red-50' : 'hover:bg-coral/5'}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isEmergency ? 'bg-red-500/15' : 'bg-coral/15'}`}>
                  <AlertTriangle className={`w-5 h-5 ${isEmergency ? 'text-red-600' : 'text-coral-dark'}`} />
                </div>
                <h3 className={`text-lg font-bold ${isEmergency ? 'text-red-700' : 'text-coral-dark'}`}>علامات خطيرة تتطلب تدخلاً طبياً فورياً</h3>
              </div>
              <motion.div
                animate={{ rotate: showWarnings ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className={`w-5 h-5 ${isEmergency ? 'text-red-600' : 'text-coral-dark'}`} />
              </motion.div>
            </button>

            {showWarnings && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <CardContent className="pt-0 pb-5 px-5">
                  <ul className="space-y-3">
                    {diagnosis.warningSigns.map((sign, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: 0.1 * index }}
                        className="flex items-start gap-3"
                      >
                        <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${isEmergency ? 'text-red-500' : 'text-coral'}`} />
                        <span className="text-foreground leading-relaxed">{sign}</span>
                      </motion.li>
                    ))}
                  </ul>
                </CardContent>
              </motion.div>
            )}
          </Card>
        </motion.div>

        {/* Medical Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-6"
        >
          <Card className="border border-teal-200 bg-muted/50">
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                <Heart className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-teal-800 mb-1">تنبيه طبي مهم</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    هذا التشخيص مبدئي واسترشادي فقط، وهو لا يُغني بأي حال عن استشارة الطبيب المختص. 
                    يجب مراجعة طبيب للحصول على تشخيص دقيق عبر الفحص السريري والتحاليل اللازمة. 
                    لا تتخذ أي قرار طبي بناءً على هذه النتائج فقط.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Restart Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-8 text-center"
        >
          <Button
            onClick={onRestart}
            size="lg"
            className={`text-white text-lg px-8 py-6 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105 font-bold ${isEmergency ? 'bg-red-600 hover:bg-red-700 shadow-red-200/50' : 'bg-teal-700 hover:bg-teal-800 shadow-teal-200/50'}`}
          >
            ابدأ تشخيصاً جديداً
            <ArrowRight className="mr-2 w-5 h-5" />
          </Button>
        </motion.div>
      </main>
    </div>
  );
}
