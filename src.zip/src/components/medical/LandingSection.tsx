"use client";

import { motion } from "framer-motion";
import { Stethoscope, Brain, ClipboardList, Shield, Smartphone, Lock, AlertTriangle, GitBranch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface LandingSectionProps {
  onStart: () => void;
}

const steps = [
  {
    icon: ClipboardList,
    title: "اختر عرضك",
    description: "حدد العرض الرئيسي الذي تعاني منه من خلال خيارات متعددة",
    color: "bg-teal-100 text-teal-800",
  },
  {
    icon: Brain,
    title: "أجب عن الأسئلة",
    description: "أجب عن أسئلة تفصيلية تساعد في تحديد طبيعة الأعراض",
    color: "bg-coral-light/40 text-coral-dark",
  },
  {
    icon: Stethoscope,
    title: "احصل على التشخيص",
    description: "احصل على تقييم مبدئي مدعوم بالذكاء الاصطناعي مع توصيات",
    color: "bg-gold-light/40 text-gold-dark",
  },
];

const features = [
  {
    emoji: "🌳",
    icon: GitBranch,
    title: "شجرة قرارات ديناميكية",
    description: "أسئلة تتفرع بناءً على إجاباتك",
    color: "from-teal-500 to-teal-600",
    bgColor: "bg-teal-50",
    borderColor: "border-teal-200",
  },
  {
    emoji: "🤖",
    icon: Brain,
    title: "ذكاء اصطناعي متقدم",
    description: "تحليل ذكي لسلسلة الأعراض",
    color: "from-coral to-coral-dark",
    bgColor: "bg-coral/5",
    borderColor: "border-coral/20",
  },
  {
    emoji: "🏥",
    icon: Stethoscope,
    title: "6 مسارات طبية",
    description: "صداع، ألم بطني، ألم صدري، مفاصل، تنفسي، وأكثر",
    color: "from-teal-600 to-teal-800",
    bgColor: "bg-teal-50",
    borderColor: "border-teal-200",
  },
  {
    emoji: "🚨",
    icon: AlertTriangle,
    title: "كشف الطوارئ",
    description: "تنبيه فوري عند اكتشاف أعراض خطيرة",
    color: "from-red-500 to-red-600",
    bgColor: "bg-red-50",
    borderColor: "border-red-200",
  },
  {
    emoji: "🔒",
    icon: Lock,
    title: "خصوصية تامة",
    description: "لا نحفظ أي بيانات شخصية",
    color: "from-gold to-gold-dark",
    bgColor: "bg-gold-light/30",
    borderColor: "border-gold/20",
  },
  {
    emoji: "📱",
    icon: Smartphone,
    title: "متجاوب بالكامل",
    description: "يعمل على جميع الأجهزة",
    color: "from-teal-500 to-coral",
    bgColor: "bg-teal-50",
    borderColor: "border-teal-200",
  },
];

export default function LandingSection({ onStart }: LandingSectionProps) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative flex-1 flex items-center justify-center overflow-hidden">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-teal-800 via-teal-700 to-teal-600" />

        {/* Decorative Circles */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-teal-500/20"
            animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-teal-400/15"
            animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.4, 0.2] }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          />
          <motion.div
            className="absolute top-1/3 left-1/4 w-48 h-48 rounded-full bg-coral/10"
            animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.25, 0.1] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-36 h-36 rounded-full bg-gold/10"
            animate={{ scale: [1, 1.15, 1], opacity: [0.15, 0.3, 0.15] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          />
        </div>

        {/* Content */}
        <div className="relative z-10 text-center px-4 py-16 max-w-4xl mx-auto">
          {/* Logo/Icon */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="mb-8"
          >
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-white/15 backdrop-blur-sm border border-white/20">
              <Stethoscope className="w-12 h-12 text-white" />
            </div>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl sm:text-6xl md:text-7xl font-bold text-white mb-2 leading-tight"
          >
            MedPath AI
          </motion.h1>

          {/* Tagline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="text-xl sm:text-2xl text-teal-100 mb-3 max-w-2xl mx-auto leading-relaxed"
          >
            تشخيص مبدئي ذكي مدعوم بالذكاء الاصطناعي
          </motion.p>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.45 }}
            className="text-base sm:text-lg text-teal-200/80 mb-10 max-w-xl mx-auto"
          >
            منصة استشارات طبية ذكية
          </motion.p>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Button
              onClick={onStart}
              size="lg"
              className="bg-coral hover:bg-coral-dark text-white text-xl px-10 py-7 rounded-2xl shadow-2xl shadow-coral/30 transition-all duration-300 hover:scale-105 hover:shadow-coral/50 font-bold"
            >
              ابدأ التشخيص الآن
              <Stethoscope className="mr-2 w-6 h-6" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* How it Works Section */}
      <section className="bg-background py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl sm:text-4xl font-bold text-center text-teal-800 mb-12"
          >
            كيف يعمل MedPath AI؟
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="text-center"
              >
                <div className="relative mb-6">
                  {/* Step Number */}
                  <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-teal-800 text-white flex items-center justify-center text-sm font-bold z-10">
                    {index + 1}
                  </div>
                  {/* Icon */}
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl ${step.color} mx-auto`}>
                    <step.icon className="w-10 h-10" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-muted/30 py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl sm:text-4xl font-bold text-center text-teal-800 mb-4"
          >
            مميزات المنصة
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-center text-muted-foreground mb-12 text-lg"
          >
            تقنيات متقدمة لتقديم أفضل تقييم مبدئي لأعراضك
          </motion.p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className={`h-full border ${feature.borderColor} ${feature.bgColor} hover:shadow-lg transition-shadow duration-300`}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white text-xl`}>
                        {feature.emoji}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-bold text-foreground mb-1">
                          {feature.title}
                        </h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Medical Disclaimer */}
      <section className="bg-muted/50 py-8 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="bg-card rounded-2xl p-6 border border-teal-200">
            <p className="text-sm text-muted-foreground leading-relaxed">
              ⚠️ <strong className="text-teal-800">تنبيه طبي مهم:</strong> هذا التطبيق يقدم تقييماً مبدئياً فقط ولا يُغني عن استشارة الطبيب المختص. 
              النتائج المقدمة هي احتمالات مبدئية وليست تشخيصاً طبياً نهائياً. يُرجى مراجعة الطبيب للحصول على تشخيص دقيق وخطة علاجية مناسبة.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
