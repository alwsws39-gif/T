"use client";

import { motion } from "framer-motion";

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  questionNumber: number;
}

export default function ProgressBar({ currentStep, totalSteps, questionNumber }: ProgressBarProps) {
  const progress = totalSteps > 0 ? (currentStep / totalSteps) * 100 : 0;

  return (
    <div className="w-full mb-6">
      {/* Step Counter */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-teal-800">
          السؤال {questionNumber} من {totalSteps}
        </span>
        <span className="text-sm text-muted-foreground">
          {Math.round(progress)}%
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-3 bg-teal-100 rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full bg-gradient-to-l from-teal-500 to-teal-700"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
