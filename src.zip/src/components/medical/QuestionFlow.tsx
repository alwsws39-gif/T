"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Question, QuestionOption, Answer } from "@/lib/decision-tree";
import { getQuestion, getFirstQuestion } from "@/lib/decision-tree";
import ProgressBar from "./ProgressBar";
import QuestionCard from "./QuestionCard";

interface QuestionFlowProps {
  onComplete: (answers: Answer[]) => void;
  onBack: () => void;
}

// Estimate total steps for a path
function estimateTotalSteps(questionId: string, depth: number = 0): number {
  if (depth > 8) return depth;
  const question = getQuestion(questionId);
  if (!question) return depth;

  let maxDepth = depth + 1;
  for (const option of question.options) {
    if (option.nextQuestionId) {
      const d = estimateTotalSteps(option.nextQuestionId, depth + 1);
      maxDepth = Math.max(maxDepth, d);
    }
  }
  return maxDepth;
}

export default function QuestionFlow({ onComplete, onBack }: QuestionFlowProps) {
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [currentQuestionId, setCurrentQuestionId] = useState<string>("root");
  const [selectedOptionId, setSelectedOptionId] = useState<string | undefined>(undefined);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const currentQuestion = getQuestion(currentQuestionId) || getFirstQuestion();
  const totalSteps = estimateTotalSteps("root");
  const currentStep = answers.length;

  const handleSelect = useCallback(
    (option: QuestionOption) => {
      if (isTransitioning) return;
      setSelectedOptionId(option.id);
      setIsTransitioning(true);

      const newAnswer: Answer = {
        questionId: currentQuestionId,
        selectedOptionId: option.id,
      };
      const newAnswers = [...answers, newAnswer];

      // Delay for visual feedback
      setTimeout(() => {
        if (option.nextQuestionId) {
          setAnswers(newAnswers);
          setCurrentQuestionId(option.nextQuestionId);
          setSelectedOptionId(undefined);
        } else {
          // End of path - go to diagnosis
          onComplete(newAnswers);
        }
        setIsTransitioning(false);
      }, 400);
    },
    [currentQuestionId, answers, onComplete, isTransitioning]
  );

  const handleGoBack = useCallback(() => {
    if (answers.length === 0) {
      onBack();
      return;
    }

    const prevAnswers = answers.slice(0, -1);
    const prevQuestionId =
      prevAnswers.length > 0
        ? (() => {
            const lastAnswer = prevAnswers[prevAnswers.length - 1];
            const lastQuestion = getQuestion(lastAnswer.questionId);
            const lastOption = lastQuestion?.options.find(
              (o) => o.id === lastAnswer.selectedOptionId
            );
            return lastOption?.nextQuestionId || "root";
          })()
        : "root";

    setAnswers(prevAnswers);
    setCurrentQuestionId(prevQuestionId);
    setSelectedOptionId(undefined);
  }, [answers, onBack]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-teal-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-teal-800 flex items-center justify-center">
                <span className="text-white text-sm font-bold">🩺</span>
              </div>
              <span className="font-bold text-teal-800 text-lg">MedPath AI</span>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleGoBack}
              className="text-teal-700 hover:bg-teal-50 gap-1"
            >
              <ArrowRight className="w-4 h-4" />
              رجوع
            </Button>
          </div>

          <ProgressBar
            currentStep={currentStep}
            totalSteps={totalSteps}
            questionNumber={answers.length + 1}
          />
        </div>
      </header>

      {/* Question Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-3xl">
          <AnimatePresence mode="wait">
            <QuestionCard
              key={currentQuestionId}
              question={currentQuestion}
              selectedOptionId={selectedOptionId}
              onSelect={handleSelect}
              questionIndex={answers.length}
            />
          </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-4 px-4 text-center">
        <p className="text-xs text-muted-foreground">
          ⚠️ هذا تقييم مبدئي فقط وليس تشخيصاً طبياً نهائياً
        </p>
      </footer>
    </div>
  );
}
