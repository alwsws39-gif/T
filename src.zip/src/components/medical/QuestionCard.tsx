"use client";

import { motion } from "framer-motion";
import type { Question, QuestionOption } from "@/lib/decision-tree";

interface QuestionCardProps {
  question: Question;
  selectedOptionId?: string;
  onSelect: (option: QuestionOption) => void;
  questionIndex: number;
}

export default function QuestionCard({ question, selectedOptionId, onSelect, questionIndex }: QuestionCardProps) {
  return (
    <motion.div
      key={question.id}
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="w-full"
    >
      {/* Question Text */}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="text-2xl sm:text-3xl font-bold text-teal-800 text-center mb-8 leading-relaxed"
      >
        {question.text}
      </motion.h2>

      {/* Options Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
        {question.options.map((option, index) => (
          <motion.button
            key={option.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.15 * index + 0.2 }}
            onClick={() => onSelect(option)}
            className={`
              group relative flex items-center gap-4 p-5 rounded-2xl border-2 transition-all duration-300 text-right
              ${
                selectedOptionId === option.id
                  ? "border-teal-600 bg-teal-50 shadow-lg shadow-teal-200/50 scale-[1.02]"
                  : "border-teal-200 bg-card hover:border-teal-400 hover:bg-teal-50/50 hover:shadow-md hover:scale-[1.01]"
              }
            `}
          >
            {/* Icon */}
            <span className="text-3xl flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
              {option.icon}
            </span>

            {/* Text */}
            <span className={`text-lg font-medium leading-relaxed ${
              selectedOptionId === option.id ? "text-teal-800" : "text-foreground"
            }`}>
              {option.text}
            </span>

            {/* Selection Indicator */}
            {selectedOptionId === option.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-3 left-3 w-6 h-6 rounded-full bg-teal-600 flex items-center justify-center"
              >
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}
