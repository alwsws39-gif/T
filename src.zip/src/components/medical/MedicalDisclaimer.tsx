"use client";

import { AlertTriangle } from "lucide-react";

interface MedicalDisclaimerProps {
  compact?: boolean;
}

export default function MedicalDisclaimer({ compact = false }: MedicalDisclaimerProps) {
  if (compact) {
    return (
      <p className="text-xs text-muted-foreground text-center">
        ⚠️ هذا التقييم مبدئي فقط وليس تشخيصاً طبياً. راجع طبيبك المختص.
      </p>
    );
  }

  return (
    <div className="bg-muted/50 border border-teal-200 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-coral flex-shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-teal-800 text-sm mb-1">تنبيه طبي</h4>
          <p className="text-xs text-muted-foreground leading-relaxed">
            هذا التطبيق يقدم تقييماً مبدئياً فقط ولا يُغني عن استشارة الطبيب المختص. 
            النتائج هي احتمالات وليست تشخيصاً طبياً نهائياً. يُرجى مراجعة الطبيب للتشخيص الدقيق.
          </p>
        </div>
      </div>
    </div>
  );
}
