"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { Answer, DiagnosisResult } from "@/lib/decision-tree";
import { getLocalDiagnosis } from "@/lib/decision-tree";
import LandingSection from "@/components/medical/LandingSection";
import QuestionFlow from "@/components/medical/QuestionFlow";
import DiagnosisResultView from "@/components/medical/DiagnosisResult";

type AppView = "landing" | "questions" | "loading" | "diagnosis";

export default function Home() {
  const [currentView, setCurrentView] = useState<AppView>("landing");
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);
  const [aiEnhanced, setAiEnhanced] = useState(false);

  const handleStart = useCallback(() => {
    setCurrentView("questions");
  }, []);

  const handleQuestionsBack = useCallback(() => {
    setCurrentView("landing");
  }, []);

  const handleQuestionsComplete = useCallback(async (answers: Answer[]) => {
    setCurrentView("loading");

    try {
      // Try AI diagnosis first
      const response = await fetch("/api/diagnose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.diagnosis) {
          setDiagnosis(data.diagnosis);
          setAiEnhanced(data.source === "ai");
          setCurrentView("diagnosis");
          return;
        }
      }
    } catch (error) {
      console.error("Failed to get AI diagnosis:", error);
    }

    // Fallback to local diagnosis
    const localResult = getLocalDiagnosis(answers);
    if (localResult) {
      setDiagnosis(localResult);
      setAiEnhanced(false);
      setCurrentView("diagnosis");
    } else {
      // If even local fails, create a generic diagnosis
      setDiagnosis({
        id: "unknown",
        name: "يتطلب تقييماً طبياً متخصصاً",
        confidence: 40,
        description:
          "بناءً على الأعراض المقدمة، لم يتم تحديد تشخيص محدد بدقة. يُنصح بمراجعة طبيب عام لإجراء فحص شامل وتحاليل لازم لتحديد التشخيص الدقيق.",
        specialty: "طبيب عام",
        advice: [
          "مراجعة طبيب عام في أقرب وقت",
          "تدوين جميع الأعراض التي تعاني منها",
          "الإفصاح عن التاريخ الطبي والأدوية الحالية",
          "الحفاظ على نمط حياة صحي",
          "عدم تجاهل الأعراض المستمرة",
        ],
        warningSigns: [
          "أي عرض شديد أو مفاجئ",
          "حمى عالية مستمرة",
          "ضيق تنفس أو ألم صدري",
          "فقدان وعي أو تشوش شديد",
        ],
      });
      setAiEnhanced(false);
      setCurrentView("diagnosis");
    }
  }, []);

  const handleRestart = useCallback(() => {
    setDiagnosis(null);
    setAiEnhanced(false);
    setCurrentView("landing");
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence mode="wait">
        {currentView === "landing" && (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            <LandingSection onStart={handleStart} />
          </motion.div>
        )}

        {currentView === "questions" && (
          <motion.div
            key="questions"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 30 }}
            transition={{ duration: 0.4 }}
          >
            <QuestionFlow
              onComplete={handleQuestionsComplete}
              onBack={handleQuestionsBack}
            />
          </motion.div>
        )}

        {currentView === "loading" && (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="min-h-screen flex flex-col items-center justify-center px-4"
          >
            {/* Animated Medical Loading */}
            <div className="text-center">
              {/* Pulsing Stethoscope */}
              <motion.div
                className="mb-8"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-teal-600 to-teal-400 shadow-2xl shadow-teal-300/50">
                  <span className="text-5xl">🩺</span>
                </div>
              </motion.div>

              {/* Animated Dots */}
              <motion.h2
                className="text-2xl font-bold text-teal-800 mb-4"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              >
                جارٍ تحليل الأعراض
              </motion.h2>

              {/* Progress Steps */}
              <div className="space-y-3 max-w-xs mx-auto">
                <LoadingStep text="مراجعة الإجابات" delay={0} />
                <LoadingStep text="تحليل نمط الأعراض" delay={0.8} />
                <LoadingStep text="إعداد التشخيص المبدئي" delay={1.6} />
              </div>

              <p className="text-sm text-muted-foreground mt-8">
                يرجى الانتظار بينما يقوم الذكاء الاصطناعي بتحليل حالتك...
              </p>
            </div>
          </motion.div>
        )}

        {currentView === "diagnosis" && diagnosis && (
          <motion.div
            key="diagnosis"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <DiagnosisResultView
              diagnosis={diagnosis}
              aiEnhanced={aiEnhanced}
              onRestart={handleRestart}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LoadingStep({ text, delay }: { text: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
      className="flex items-center gap-3 bg-card rounded-xl px-4 py-3 border border-teal-200"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3, delay: delay + 0.3 }}
        className="w-6 h-6 rounded-full bg-teal-500 flex items-center justify-center flex-shrink-0"
      >
        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
        </svg>
      </motion.div>
      <span className="text-teal-800 font-medium text-sm">{text}</span>
    </motion.div>
  );
}
