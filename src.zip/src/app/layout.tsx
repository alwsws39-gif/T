import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "MedPath AI - تشخيص طبي ذكي",
  description: "تشخيص مبدئي ذكي مدعوم بالذكاء الاصطناعي - احصل على تقييم أولي لأعراضك الصحية عبر شجرة قرارات ديناميكية",
  keywords: ["تشخيص طبي", "ذكاء اصطناعي", "MedPath AI", "أعراض", "صحة", "استشارة طبية"],
  authors: [{ name: "MedPath AI" }],
  icons: {
    icon: "/favicon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${cairo.variable} antialiased bg-background text-foreground font-[family-name:var(--font-cairo)]`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
