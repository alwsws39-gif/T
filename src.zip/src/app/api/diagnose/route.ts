import ZAI from "z-ai-web-dev-sdk";
import { NextResponse } from "next/server";
import { getPathSummary, getLocalDiagnosis } from "@/lib/decision-tree";
import type { Answer, DiagnosisResult } from "@/lib/decision-tree";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { answers }: { answers: Answer[] } = body;

    if (!answers || !Array.isArray(answers) || answers.length === 0) {
      return NextResponse.json(
        { error: "لم يتم توفير إجابات كافية للتشخيص" },
        { status: 400 }
      );
    }

    // Get the local fallback diagnosis
    const localDiagnosis = getLocalDiagnosis(answers);

    // Build the path summary for AI
    const pathSummary = getPathSummary(answers);

    try {
      // Try AI diagnosis
      const zai = await ZAI.create();
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: `أنت MedPath AI - مساعد طبي ذكي متخصص في التشخيص المبدئي. أنت جزء من منصة استشارات طبية ذكية تقدم تقييمات مبدئية مدعومة بالذكاء الاصطناعي.

بناءً على إجابات المريض عبر شجرة القرارات الديناميكية، قدم تشخيصاً مبدئياً بصيغة JSON فقط (بدون أي نص إضافي).

يجب أن تكون الإجابة بصيغة JSON التالية فقط:
{
  "name": "اسم التشخيص بالعربية",
  "confidence": رقم من 50 إلى 95 يمثل نسبة الثقة,
  "description": "وصف تفصيلي بالعربية للحالة",
  "specialty": "التخصص الطبي الموصى به بالعربية",
  "advice": ["نصيحة 1 بالعربية", "نصيحة 2", ...],
  "warningSigns": ["علامة خطيرة 1", "علامة خطيرة 2", ...],
  "urgency": "طارئ" أو "عاجل" أو "غير عاجل"
}

قواعد تقييم الاستعجال (urgency):
- "طارئ": حالات تهدد الحياة وتتطلب تدخلاً فورياً (مثل: جلطة قلبية، نزيف دماغي، صداع الأسوأ في الحياة مع أعراض عصبية، التهاب زائدة متقدّم)
- "عاجل": حالات تحتاج مراجعة طبية سريعة خلال ساعات (مثل: حصوات كلوية، حصوات مرارة مع مضاعفات، التهاب رئوي)
- "غير عاجل": حالات يمكن مراجعة الطبيب فيها بشكل روتيني (مثل: صداع توتر، زكام، التهاب أنف تحسسي)

قواعد سريرية مهمة:
- إذا كان ألم الصدر مترافقاً مع ألم ذراع أيسر وتعرق بارد → "طارئ" (جلطة قلبية محتملة)
- إذا كان الصداع مفاجئاً وشديداً جداً (الأسوأ في الحياة) → "طارئ" (طوارئ عصبية)
- إذا كان ألم البطن حول السرة ينتقل لليمنى السفلي مع حمى → "طارئ" (التهاب زائدة)
- يجب دائماً أن تذكر ضرورة مراجعة الطبيب
- يجب أن تتضمن علامات التحذير التي تستدعي التدخل الطبي الفوري
- اجعل الوصف طبياً دقيقاً لكن مفهوماً للعامة
- النسبة المئوية للثقة يجب أن تكون واقعية
- قدم 5-7 نصائح على الأقل
- قدم 3-5 علامات تحذيرية على الأقل`,
          },
          {
            role: "user",
            content: `بناءً على الإجابات التالية لمريض، ما هو التشخيص المبدئي؟

${pathSummary}

التشخيص المحتمل من شجرة القرار: ${localDiagnosis?.name || "غير محدد بعد"}
مستوى الاستعجال المحلي: ${localDiagnosis?.urgency || "غير محدد"}

يرجى تقديم تشخيص مبدئي مفصل بصيغة JSON فقط مع تحديد مستوى الاستعجال.`,
          },
        ],
      });

      // Extract the AI response
      const aiContent =
        completion.choices?.[0]?.message?.content || "";

      // Try to parse JSON from the AI response
      let jsonStr = aiContent;
      // Handle markdown code blocks
      const jsonMatch = aiContent.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1];
      }

      // Clean up the JSON string
      jsonStr = jsonStr.trim();

      const aiDiagnosis = JSON.parse(jsonStr);

      // Validate the structure
      if (
        aiDiagnosis.name &&
        aiDiagnosis.description &&
        aiDiagnosis.specialty &&
        Array.isArray(aiDiagnosis.advice) &&
        Array.isArray(aiDiagnosis.warningSigns)
      ) {
        // Validate urgency field
        const validUrgencyValues = ["طارئ", "عاجل", "غير عاجل"];
        const aiUrgency = validUrgencyValues.includes(aiDiagnosis.urgency)
          ? aiDiagnosis.urgency
          : localDiagnosis?.urgency || "غير عاجل";

        const diagnosis: DiagnosisResult = {
          id: localDiagnosis?.id || "ai-diagnosis",
          name: aiDiagnosis.name,
          confidence: Math.min(95, Math.max(50, Number(aiDiagnosis.confidence) || localDiagnosis?.confidence || 70)),
          description: aiDiagnosis.description,
          specialty: aiDiagnosis.specialty,
          advice: aiDiagnosis.advice,
          warningSigns: aiDiagnosis.warningSigns,
          urgency: aiUrgency,
        };

        return NextResponse.json({
          diagnosis,
          source: "ai",
        });
      }
    } catch (aiError) {
      console.error("AI diagnosis failed, using fallback:", aiError);
    }

    // Fallback to local diagnosis
    if (localDiagnosis) {
      return NextResponse.json({
        diagnosis: localDiagnosis,
        source: "local",
      });
    }

    // If no diagnosis available at all
    return NextResponse.json(
      {
        error: "لم يتم العثور على تشخيص مناسب. يرجى مراجعة طبيب مختص.",
      },
      { status: 404 }
    );
  } catch (error) {
    console.error("Diagnosis API error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء التشخيص. يرجى المحاولة مرة أخرى." },
      { status: 500 }
    );
  }
}
